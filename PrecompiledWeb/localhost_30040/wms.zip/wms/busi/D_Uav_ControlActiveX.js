﻿mini.parse();

var _SetTimeYG = 1000;//读取 ActiveX控件从 C:\TFHandle.txt 获取的摇杆信息

//StartInterval();

function StartInterval() {
    window.setInterval("GetYGInfo()", _SetTimeYG);//每_SetTimeYG秒执行一次
}

//每100毫秒读取摇杆操作信息
function GetYGInfo() {
     
    //说明：归位值 32767
    //最小值： 0
    //最大值： 65535

    var axisA = YGObject.AxisA;//速度加减(飞控接口未开发)
    var axisB = YGObject.AxisB;//偏航角ψ（yaw）左飞或右飞
    var axisC = YGObject.AxisC;//滚转角Φ（roll）(飞控接口未开发)
    var axisD = YGObject.AxisD;//爬高或下降/俯仰角
    //暂且只使用 axisB 和 axisD.(axisB可代替页面上的 左飞或右飞) (axisD可代替页面上的 爬高或下降) 

    
     
    //头盔视角
    //var pointOfViewCount = YGObject.pointOfViewCount;
    //var pointOfView = YGObject.pointOfView;
    //var buttonsStr = YGObject.buttonsStr;//触发摇杆上的按钮

    //showCBInfo("pointOfViewCount: " + pointOfViewCount);
    //showCBInfo("pointOfView: " + pointOfView);
    //showCBInfo("axisA: " + axisA);
    //showCBInfo("axisB: " + axisB);
    //showCBInfo("axisC: " + axisC);
    //showCBInfo("axisD: " + axisD);
    //showCBInfo("buttonsStr: " + YGObject.buttonsStr);

    //buttonsStr内容 1:False|2:False|3:False|4:False|5:False|6:False|7:False|8:False|9:False|10:False|11:False|12:False|13:False|14:False|15:False
    //|16:False|17:False|18:False|19:False|20:False|21:False|22:False|23:False|24:False|25:False|26:False|27:False|28:False|29:False|30:False|31:False
    //|32:False|33:False|34:False|35:False|36:False|37:False|38:False|39:False|40:False|41:False|42:False|43:False|44:False|45:False|46:False|47:False
    //|48:False|49:False|50:False|51:False|52:False|53:False|54:False|55:False|56:False|57:False|58:False|59:False|60:False|61:False|62:False|63:False
    //|64:False|65:False|66:False|67:False|68:False|69:False|70:False|71:False|72:False|73:False|74:False|75:False|76:False|77:False|78:False|79:False
    //|80:False|81:False|82:False|83:False|84:False|85:False|86:False|87:False|88:False|89:False|90:False|91:False|92:False|93:False|94:False|95:False
    //|96:False|97:False|98:False|99:False|100:False|101:False|102:False|103:False|104:False|105:False|106:False|107:False|108:False|109:False|110:False
    //|111:False|112:False|113:False|114:False|115:False|116:False|117:False|118:False|119:False|120:False|121:False|122:False|123:False|124:False
    //|125:False|126:False|127:False|128:False

    //pointOfView
    //1:-1
}

