﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// SpecialEditPageManager 的摘要说明
/// </summary>
public class SpecialEditPageManager
{
	public SpecialEditPageManager()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public static void ManagerResult(VLP.BS.LoadFormResult result, string pageid, string billid,Nordasoft.Data.Sql.DataBase db,System.Web.SessionState.HttpSessionState session)
    {

    }
}